import { Component, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { lastValueFrom } from 'rxjs';
import {
  injectQuery,
  injectMutation,
  injectQueryClient,
} from '@tanstack/angular-query-experimental';
import { SystemConfigDetailDto } from '../../models';
import {
  SystemConfigService,
  CreateSystemConfigDto,
  UpdateSystemConfigDto,
} from '../../services/system-config.service';

@Component({
  selector: 'app-system-config',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './system-config.component.html',
  styleUrl: './system-config.component.css',
})
export class SystemConfigComponent {
  private systemConfigService = inject(SystemConfigService);
  private queryClient = injectQueryClient();

  page = signal(1);
  pageSize = signal(15);
  search = signal('');

  showModal = signal(false);
  isEdit = signal(false);
  form = signal<any>({ key: '', value: '', description: '' });
  editId = signal<number | null>(null);
  toast = signal<{ msg: string; ok: boolean } | null>(null);

  // ── Queries ──────────────────────────────────────────────────────────────

  listQuery = injectQuery(() => ({
    queryKey: ['system-configs', this.page(), this.pageSize(), this.search()],
    queryFn: () =>
      lastValueFrom(
        this.systemConfigService.getPaged({
          pageIndex: this.page(),
          pageSize: this.pageSize(),
          keyword: this.search(),
        })
      ),
  }));

  configs = computed<SystemConfigDetailDto[]>(() => {
    const d = (this.listQuery.data() as any)?.data;
    return d?.items ?? [];
  });
  totalRecords = computed<number>(() => {
    const d = (this.listQuery.data() as any)?.data;
    return d?.totalCount ?? 0;
  });
  totalPages = computed<number>(() => {
    const d = (this.listQuery.data() as any)?.data;
    return d?.totalPages ?? 0;
  });
  loading = computed(() => this.listQuery.isPending());

  // ── Mutations ─────────────────────────────────────────────────────────────

  createMutation = injectMutation(() => ({
    mutationFn: (payload: CreateSystemConfigDto) =>
      lastValueFrom(this.systemConfigService.create(payload)),
    onSuccess: (r: any) => {
      if (r.isSucceeded) {
        this.closeModal();
        this.queryClient.invalidateQueries({ queryKey: ['system-configs'] });
        this.showToast('Thêm thành công!');
      } else this.showToast(r.message || 'Lỗi', false);
    },
    onError: (err: any) => this.showToast(err?.error?.message || 'Lỗi', false),
  }));

  updateMutation = injectMutation(() => ({
    mutationFn: (payload: UpdateSystemConfigDto) =>
      lastValueFrom(this.systemConfigService.update(payload)),
    onSuccess: (r: any) => {
      if (r.isSucceeded) {
        this.closeModal();
        this.queryClient.invalidateQueries({ queryKey: ['system-configs'] });
        this.showToast('Cập nhật thành công!');
      } else this.showToast(r.message || 'Lỗi', false);
    },
    onError: (err: any) => this.showToast(err?.error?.message || 'Lỗi', false),
  }));

  deleteMutation = injectMutation(() => ({
    mutationFn: (id: number) =>
      lastValueFrom(this.systemConfigService.delete(id)),
    onSuccess: (r: any) => {
      if (r.isSucceeded) {
        this.queryClient.invalidateQueries({ queryKey: ['system-configs'] });
        this.showToast('Đã xóa!');
      } else this.showToast(r.message || 'Lỗi', false);
    },
  }));

  saving = computed(
    () => this.createMutation.isPending() || this.updateMutation.isPending()
  );

  // ── UI Helpers ────────────────────────────────────────────────────────────

  onSearch(): void { this.page.set(1); }
  setPage(p: number): void {
    if (p < 1 || p > this.totalPages()) return;
    this.page.set(p);
  }
  pages(): number[] {
    const t = this.totalPages(), c = this.page(), d = 2, ps: number[] = [];
    for (let i = Math.max(1, c - d); i <= Math.min(t, c + d); i++) ps.push(i);
    return ps;
  }

  openCreate(): void {
    this.isEdit.set(false);
    this.editId.set(null);
    this.form.set({ key: '', value: '', description: '' });
    this.showModal.set(true);
  }
  openEdit(c: SystemConfigDetailDto): void {
    this.isEdit.set(true);
    this.editId.set(c.id);
    this.form.set({ key: c.key, value: c.value, description: c.description || '' });
    this.showModal.set(true);
  }
  closeModal(): void { this.showModal.set(false); }
  setField(f: string, v: any): void {
    this.form.update((x) => ({ ...x, [f]: v }));
  }

  save(): void {
    const f = this.form();
    if (!f.key || !f.value) { this.showToast('Key và Value là bắt buộc', false); return; }
    if (this.isEdit()) {
      this.updateMutation.mutate({ ...f, id: this.editId()! } as UpdateSystemConfigDto);
    } else {
      this.createMutation.mutate(f as CreateSystemConfigDto);
    }
  }

  delete(id: number, key: string): void {
    if (!confirm(`Xóa cấu hình "${key}"?`)) return;
    this.deleteMutation.mutate(id);
  }

  private showToast(msg: string, ok = true): void {
    this.toast.set({ msg, ok });
    setTimeout(() => this.toast.set(null), 3000);
  }
}
